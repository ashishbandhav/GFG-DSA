# Segment and Binary Indexed Trees
