# GeeksForGeeks

## Data Structures and Algorithms

> ### [Mathematics](https://github.com/G1Joshi/GFG-DSA/tree/main/Mathematics)

> ### [Arrays](https://github.com/G1Joshi/GFG-DSA/tree/main/Arrays)
