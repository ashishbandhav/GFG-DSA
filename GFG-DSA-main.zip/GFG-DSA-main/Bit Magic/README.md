# Bit Magic
